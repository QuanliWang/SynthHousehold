//  sampleHouseholds.h
#define DIM 8
void sampleHouseholds_imp(double* data, double* rand,  double* lambda1, double* lambda2, double* w, double* phi,
                      double *pi, double* d,int nHouseholds, int householdsize, int K,int L,
                      int maxdd, int p, int lambda1_columns, int currrentbatch);
