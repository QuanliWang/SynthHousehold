//  sampleHouseholds.h
#define DIM 8
void sampleHouseholds_imp(double* data, double* rand,  double** lambda, int* lambda_columns, double* w, double* phi,
                      double *pi, double* d,int nHouseholds, int householdsize, int K,int L,
                      int maxdd, int p, int currrentbatch, int n_lambdas);
